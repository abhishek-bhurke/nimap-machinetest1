export class UserDetails {
    file?: string;
    fname?: string;
    lname?: string;
    mail?: string;
    pass?: string;
    mno?: string;
    age?: string;
    city?: string;
    state?: string;
    country?: string;
    address?: string;
    address1?: string;
    address2?: string;
    tags?: string;
    che?: string;

    UserDetails() { }

}
